package io.zipcoder.tc_spring_poll_application;

public class QuickPollApplicationTest {
}